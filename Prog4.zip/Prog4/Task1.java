import java.lang.Math;
import java.util.Scanner;
public class Task1{
    //public int[] refString = new int[10];
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        //System.out.print("Number of frames for OPR: ");
        //int frameCount = input.nextInt();
        int[] refString = new int[10];
        //int[] reference = {5, 6, 2, 7, 4, 7, 0, 3, 3, 1};
        refString = populateString(refString);
        LRU1(refString);
        LRU2(refString);
        LRU3(refString);
        LRU4(refString);
        LRU5(refString);
        LRU6(refString);
        LRU7(refString);
        System.out.println("");
        optimal(refString);
    }
    
    public static void LRU1(int[] ref){
        int faults = 0;
        int frame = 9999; //Default value to avoid any chance of the number being the same as in reference string
        for(int i = 0; i < ref.length; i++){
            if(frame != ref[i]){
                frame = ref[i];
                faults++;
            }
        }
        System.out.println("LRU page faults for 1 frame: " + faults);
    }
    
    public static void LRU2(int[] ref){
        int faults = 0;
        int[][] frames = new int[2][1];
        int[][] counter = new int[2][1];
        int[][] filled = new int[2][1];
        for(int i = 0; i < ref.length; i++){
            if(i < 2){
                if((frames[i][0] != ref[i])||(filled[i][0] != 1)){
                    frames[i][0] = ref[i];
                    filled[i][0] = 1;
                    faults++;
                    for(int j = 0; j < frames.length; j++){
                        if((frames[j][0] == ref[j])&&(filled[j][0] == 1))
                            counter[j][0]++;
                    }
                }
                else
                    continue;
            }
            else{
                if(frames[0][0] == ref[i]){
                    counter[0][0] = 0;
                    counter[1][0]++;
                    continue;
                }
                else if(frames[1][0] == ref[i]){
                    counter[1][0] = 0;
                    counter[0][0]++;
                    continue;
                }
                else if(counter[0][0] > counter[1][0]){
                    frames[0][0] = ref[i];
                    counter[0][0] = 0;
                    counter[1][0]++;
                    faults++;
                }
                else if(counter[1][0] > counter[0][0]){
                    frames[1][0] = ref[i];
                    counter[1][0] = 0;
                    counter[0][0]++;
                    faults++;
                }
            }
        }
        System.out.println("LRU page faults for " + frames.length + " frames: " + faults);
    }
    
    public static void LRU3(int[] ref){
        int faults = 0;
        int[][] frames = new int[3][1];
        int[][] counter = new int[3][1];
        int[][] filled = new int[3][1];
        for(int i = 0; i < ref.length; i++){
            if(i < 3){
                if((frames[i][0] != ref[i])||(filled[i][0] != 1)){
                    frames[i][0] = ref[i];
                    filled[i][0] = 1;
                    faults++;
                    for(int j = 0; j < frames.length; j++){
                        if((frames[j][0] == ref[j])&&(filled[j][0] == 1))
                            counter[j][0]++;
                    }
                }
                else
                    continue;
            }
            else{
                if(frames[0][0] == ref[i]){
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    continue;
                }
                else if(frames[1][0] == ref[i]){
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    continue;
                }
                else if(frames[2][0] == ref[i]){
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    continue;
                }
                else if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0])){
                    frames[0][0] = ref[i];
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    faults++;
                }
                else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0])){
                    frames[1][0] = ref[i];
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    faults++;
                }
                else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0])){
                    frames[2][0] = ref[i];
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    faults++;
                }
            }
        }
        System.out.println("LRU page faults for " + frames.length + " frames: " + faults);
    }
    
    public static void LRU4(int[] ref){
        int faults = 0;
        int[][] frames = new int[4][1];
        int[][] counter = new int[4][1];
        int[][] filled = new int[4][1];
        for(int i = 0; i < ref.length; i++){
            if(i < 4){
                if((frames[i][0] != ref[i])||(filled[i][0] != 1)){
                    frames[i][0] = ref[i];
                    filled[i][0] = 1;
                    faults++;
                    for(int j = 0; j < frames.length; j++){
                        if((frames[j][0] == ref[j])&&(filled[j][0] == 1))
                            counter[j][0]++;
                    }
                }
                else
                    continue;
            }
            else{
                if(frames[0][0] == ref[i]){
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    continue;
                }
                else if(frames[1][0] == ref[i]){
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    continue;
                }
                else if(frames[2][0] == ref[i]){
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    continue;
                }
                else if(frames[3][0] == ref[i]){
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                }
                else if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0])){
                    frames[0][0] = ref[i];
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    faults++;
                }
                else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0])){
                    frames[1][0] = ref[i];
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    faults++;
                }
                else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0])){
                    frames[2][0] = ref[i];
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    faults++;
                }
                else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0])){
                    frames[3][0] = ref[i];
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    faults++;
                }
            }
        }
        System.out.println("LRU page faults for " + frames.length + " frames: " + faults);
    }
    
    public static void LRU5(int[] ref){
        int faults = 0;
        int[][] frames = new int[5][1];
        int[][] counter = new int[5][1];
        int[][] filled = new int[5][1];
        for(int i = 0; i < ref.length; i++){
            if(i < 5){
                if((frames[i][0] != ref[i])||(filled[i][0] != 1)){
                    frames[i][0] = ref[i];
                    filled[i][0] = 1;
                    faults++;
                    for(int j = 0; j < frames.length; j++){
                        if((frames[j][0] == ref[j])&&(filled[j][0] == 1))
                            counter[j][0]++;
                    }
                }
                else
                    continue;
            }
            else{
                if(frames[0][0] == ref[i]){
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    continue;
                }
                else if(frames[1][0] == ref[i]){
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    continue;
                }
                else if(frames[2][0] == ref[i]){
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    continue;
                }
                else if(frames[3][0] == ref[i]){
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[4][0]++;
                }
                else if(frames[4][0] == ref[i]){
                    counter[4][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                }
                else if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0])){
                    frames[0][0] = ref[i];
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    faults++;
                }
                else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0])){
                    frames[1][0] = ref[i];
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    faults++;
                }
                else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0])){
                    frames[2][0] = ref[i];
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    faults++;
                }
                else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0])){
                    frames[3][0] = ref[i];
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[4][0]++;
                    faults++;
                }
                else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0])){
                    frames[4][0] = ref[i];
                    counter[4][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    faults++;
                }
            }
        }
        System.out.println("LRU page faults for " + frames.length + " frames: " + faults);
    }
    
    public static void LRU6(int[] ref){
        int faults = 0;
        int[][] frames = new int[6][1];
        int[][] counter = new int[6][1];
        int[][] filled = new int[6][1];
        for(int i = 0; i < ref.length; i++){
            if(i < 5){
                if((frames[i][0] != ref[i])||(filled[i][0] != 1)){
                    frames[i][0] = ref[i];
                    filled[i][0] = 1;
                    faults++;
                    for(int j = 0; j < frames.length; j++){
                        if((frames[j][0] == ref[j])&&(filled[j][0] == 1))
                            counter[j][0]++;
                    }
                }
                else
                    continue;
            }
            else{
                if(frames[0][0] == ref[i]){
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    continue;
                }
                else if(frames[1][0] == ref[i]){
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    continue;
                }
                else if(frames[2][0] == ref[i]){
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    continue;
                }
                else if(frames[3][0] == ref[i]){
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                }
                else if(frames[4][0] == ref[i]){
                    counter[4][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[5][0]++;
                }
                else if(frames[5][0] == ref[i]){
                    counter[5][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                }
                else if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0]) && (counter[0][0] > counter[5][0])){
                    frames[0][0] = ref[i];
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    faults++;
                }
                else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0]) && (counter[1][0] > counter[5][0])){
                    frames[1][0] = ref[i];
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    faults++;
                }
                else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0]) && (counter[2][0] > counter[5][0])){
                    frames[2][0] = ref[i];
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    faults++;
                }
                else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0]) && (counter[3][0] > counter[5][0])){
                    frames[3][0] = ref[i];
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    faults++;
                }
                else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0]) && (counter[4][0] > counter[5][0])){
                    frames[4][0] = ref[i];
                    counter[4][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[5][0]++;
                    faults++;
                }
                else if((counter[5][0] > counter[0][0]) && (counter[5][0] > counter[1][0]) && (counter[5][0] > counter[2][0]) && (counter[5][0] > counter[3][0]) && (counter[5][0] > counter[4][0])){
                    frames[5][0] = ref[i];
                    counter[5][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    faults++;
                }
            }
        }
        System.out.println("LRU page faults for " + frames.length + " frames: " + faults);
    }
    
    public static void LRU7(int[] ref){
        int faults = 0;
        int[][] frames = new int[7][1];
        int[][] counter = new int[7][1];
        int[][] filled = new int[7][1];
        for(int i = 0; i < ref.length; i++){
            if(i < 5){
                if((frames[i][0] != ref[i])||(filled[i][0] != 1)){
                    frames[i][0] = ref[i];
                    filled[i][0] = 1;
                    faults++;
                    for(int j = 0; j < frames.length; j++){
                        if((frames[j][0] == ref[j])&&(filled[j][0] == 1))
                            counter[j][0]++;
                    }
                }
                else
                    continue;
            }
            else{
                if(frames[0][0] == ref[i]){
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    continue;
                }
                else if(frames[1][0] == ref[i]){
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    continue;
                }
                else if(frames[2][0] == ref[i]){
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    continue;
                }
                else if(frames[3][0] == ref[i]){
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                }
                else if(frames[4][0] == ref[i]){
                    counter[4][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                }
                else if(frames[5][0] == ref[i]){
                    counter[5][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[6][0]++;
                }
                else if(frames[6][0] == ref[i]){
                    counter[6][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                }
                else if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0]) && (counter[0][0] > counter[5][0]) && (counter[0][0] > counter[6][0])){
                    frames[0][0] = ref[i];
                    counter[0][0] = 0;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    faults++;
                }
                else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0]) && (counter[1][0] > counter[5][0]) && (counter[1][0] > counter[6][0])){
                    frames[1][0] = ref[i];
                    counter[1][0] = 0;
                    counter[0][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    faults++;
                }
                else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0]) && (counter[2][0] > counter[5][0]) && (counter[2][0] > counter[6][0])){
                    frames[2][0] = ref[i];
                    counter[2][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    faults++;
                }
                else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0]) && (counter[3][0] > counter[5][0]) && (counter[3][0] > counter[6][0])){
                    frames[3][0] = ref[i];
                    counter[3][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    faults++;
                }
                else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0]) && (counter[4][0] > counter[5][0]) && (counter[4][0] > counter[6][0])){
                    frames[4][0] = ref[i];
                    counter[4][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[5][0]++;
                    counter[6][0]++;
                    faults++;
                }
                else if((counter[5][0] > counter[0][0]) && (counter[5][0] > counter[1][0]) && (counter[5][0] > counter[2][0]) && (counter[5][0] > counter[3][0]) && (counter[5][0] > counter[4][0]) && (counter[5][0] > counter[6][0])){
                    frames[5][0] = ref[i];
                    counter[5][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[6][0]++;
                    faults++;
                }
                else if((counter[6][0] > counter[0][0]) && (counter[6][0] > counter[1][0]) && (counter[6][0] > counter[2][0]) && (counter[6][0] > counter[3][0]) && (counter[6][0] > counter[4][0]) && (counter[6][0] > counter[5][0])){
                    frames[6][0] = ref[i];
                    counter[6][0] = 0;
                    counter[0][0]++;
                    counter[1][0]++;
                    counter[2][0]++;
                    counter[3][0]++;
                    counter[4][0]++;
                    counter[5][0]++;
                    faults++;
                }
            }
        }
        System.out.println("LRU page faults for " + frames.length + " frames: " + faults);
    }
    
    public static void optimal(int[] ref){
        int faults = 0;
        int frames1 = 9999;
        int[][] frames2 = new int[2][1];
        int[][] frames3 = new int[3][1];
        int[][] frames4 = new int[4][1];
        int[][] frames5 = new int[5][1];
        int[][] frames6 = new int[6][1];
        int[][] frames7 = new int[7][1];
        int[][] counter = new int[7][1];
        int[][] counter2 = new int[7][1];
        //int[][] filled = new int[frameNum][1];
        
        //1 Frame
        for(int i = 0; i < ref.length; i++){
            if(frames1 != ref[i]){
                frames1 = ref[i];
                faults++;
            }
        }
        System.out.println("OPR page faults for 1 frame: " + faults);
        faults = 0;
        
        //2 Frames
        for(int i = 0; i < ref.length; i++){
            if(i < frames2.length){
                if(i > 0){
                    if(frames2[0][0] == ref[i]){
                        counter2[0][0]++;
                        continue;
                    }
                }
                frames2[i][0] = ref[i];
                if(i == 0)
                    counter2[0][0]++;
                if(i == 1){
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                faults++;
            }
            else{
                if(frames2[0][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    continue;
                }
                if(frames2[1][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    continue;
                }
                if(i != (ref.length-1)){
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames2[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames2[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    if(counter[0][0] > counter[1][0]){
                        frames2[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if(counter[1][0] > counter[0][0]){
                        frames2[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else{
                        if(counter2[0][0] > counter2[1][0]){
                            frames2[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if(counter2[1][0] > counter2[0][0]){
                            frames2[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                else if(i == (ref.length - 1)){
                    for(int j = i; j < ref.length; j++){
                        if(frames2[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames2[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    if(counter[0][0] > counter[1][0]){
                        frames2[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if(counter[1][0] > counter[0][0]){
                        frames2[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else{
                        if(counter2[0][0] > counter2[1][0]){
                            frames2[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if(counter2[1][0] > counter2[0][0]){
                            frames2[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
            }
        }
        System.out.println("OPR page faults for 2 frames: " + faults);
        faults = 0;
        
        //3 Frames
        for(int i = 0; i < ref.length; i++){
            if(i < frames3.length){
                if(i > 0){
                    if(frames3[0][0] == ref[i]){
                        counter2[0][0]++;
                        continue;
                    }
                    else if(frames3[1][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        continue;
                    }
                }
                frames3[i][0] = ref[i];
                if(i == 0)
                    counter2[0][0]++;
                if(i == 1){
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                if(i == 2){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
                faults++;
            }
            else{
                if(frames3[0][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    continue;
                }
                else if(frames3[1][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    continue;
                }
                else if(frames3[2][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    continue;
                }
                if(i != (ref.length-1)){
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames3[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames3[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames3[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0])){
                        frames3[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0])){
                        frames3[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0])){
                        frames3[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0])){
                            frames3[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0])){
                            frames3[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0])){
                            frames3[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
                else if(i == (ref.length - 1)){
                    for(int j = i; j < ref.length; j++){
                        if(frames3[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames3[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames3[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0])){
                        frames3[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0])){
                        frames3[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0])){
                        frames3[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0])){
                            frames3[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0])){
                            frames3[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0])){
                            frames3[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
            }
        }
        System.out.println("OPR page faults for 3 frames: " + faults);
        faults = 0;
        
        //4 Frames
        for(int i = 0; i < ref.length; i++){
            if(i < frames4.length){
                if(i > 0){
                    if(frames4[0][0] == ref[i]){
                        counter2[0][0]++;
                        continue;
                    }
                    else if(frames4[1][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        continue;
                    }
                    else if(frames4[2][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        continue;
                    }
                }
                frames4[i][0] = ref[i];
                if(i == 0)
                    counter2[0][0]++;
                if(i == 1){
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                if(i == 2){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
                if(i == 3){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                }
                faults++;
            }
            else{
                if(frames4[0][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    continue;
                }
                else if(frames4[1][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    continue;
                }
                else if(frames4[2][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    continue;
                }
                else if(frames4[3][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    continue;
                }
                if(i != (ref.length-1)){
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames4[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames4[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames4[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames4[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0])){
                        frames4[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0])){
                        frames4[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0])){
                        frames4[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0])){
                        frames4[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0])){
                            frames4[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0])){
                            frames4[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0])){
                            frames4[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0])){
                            frames4[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                }
                else if(i == (ref.length - 1)){
                    for(int j = i; j < ref.length; j++){
                        if(frames4[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames4[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames4[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames4[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0])){
                        frames4[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0])){
                        frames4[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0])){
                        frames4[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0])){
                        frames4[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0])){
                            frames4[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0])){
                            frames4[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0])){
                            frames4[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0])){
                            frames4[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                }
            }
        }
        System.out.println("OPR page faults for 4 frames: " + faults);
        faults = 0;
        
        //5 Frames
        for(int i = 0; i < ref.length; i++){
            if(i < frames5.length){
                if(i > 0){
                    if(frames5[0][0] == ref[i]){
                        counter2[0][0]++;
                        continue;
                    }
                    else if(frames5[1][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        continue;
                    }
                    else if(frames5[2][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        continue;
                    }
                    else if(frames5[3][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        counter2[3][0]++;
                        continue;
                    }
                }
                frames5[i][0] = ref[i];
                if(i == 0)
                    counter2[0][0]++;
                if(i == 1){
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                if(i == 2){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
                if(i == 3){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                }
                if(i == 4){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                }
                faults++;
            }
            else{
                if(frames5[0][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    continue;
                }
                else if(frames5[1][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    continue;
                }
                else if(frames5[2][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    continue;
                }
                else if(frames5[3][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    continue;
                }
                else if(frames5[4][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    continue;
                }
                if(i != (ref.length-1)){
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames5[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames5[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames5[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames5[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames5[4][0] == ref[j])
                            break;
                        counter[4][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0])){
                        frames5[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0])){
                        frames5[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0])){
                        frames5[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0])){
                        frames5[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0])){
                        frames5[4][0] = ref[i];
                        counter2[4][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0]) && (counter2[0][0] > counter2[4][0])){
                            frames5[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0]) && (counter2[1][0] > counter2[4][0])){
                            frames5[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0]) && (counter2[2][0] > counter2[4][0])){
                            frames5[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0]) && (counter2[3][0] > counter2[4][0])){
                            frames5[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                        else if((counter2[4][0] > counter2[0][0]) && (counter2[4][0] > counter2[1][0]) && (counter2[4][0] > counter2[2][0]) && (counter2[4][0] > counter2[3][0])){
                            frames5[4][0] = ref[i];
                            counter2[4][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter[4][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                }
                else if(i == (ref.length - 1)){
                    for(int j = i; j < ref.length; j++){
                        if(frames5[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames5[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames5[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames5[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames5[4][0] == ref[j])
                            break;
                        counter[4][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0])){
                        frames5[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0])){
                        frames5[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0])){
                        frames5[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0])){
                        frames5[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0])){
                        frames5[4][0] = ref[i];
                        counter2[4][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0]) && (counter2[0][0] > counter2[4][0])){
                            frames5[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0]) && (counter2[1][0] > counter2[4][0])){
                            frames5[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0]) && (counter2[2][0] > counter2[4][0])){
                            frames5[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0]) && (counter2[3][0] > counter2[4][0])){
                            frames5[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                        else if((counter2[4][0] > counter2[0][0]) && (counter2[4][0] > counter2[1][0]) && (counter2[4][0] > counter2[2][0]) && (counter2[4][0] > counter2[3][0])){
                            frames5[4][0] = ref[i];
                            counter2[4][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter[4][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                }
            }
        }
        System.out.println("OPR page faults for 5 frames: " + faults);
        faults = 0;
        
        //6 Frames
        for(int i = 0; i < ref.length; i++){
            if(i < frames6.length){
                if(i > 0){
                    if(frames6[0][0] == ref[i]){
                        counter2[0][0]++;
                        continue;
                    }
                    else if(frames6[1][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        continue;
                    }
                    else if(frames6[2][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        continue;
                    }
                    else if(frames6[3][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        counter2[3][0]++;
                        continue;
                    }
                    else if(frames6[4][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        counter2[3][0]++;
                        counter2[4][0]++;
                        continue;
                    }
                }
                frames6[i][0] = ref[i];
                if(i == 0)
                    counter2[0][0]++;
                if(i == 1){
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                if(i == 2){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
                if(i == 3){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                }
                if(i == 4){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                }
                if(i == 5){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                }
                faults++;
            }
            else{
                if(frames6[0][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    continue;
                }
                else if(frames6[1][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    continue;
                }
                else if(frames6[2][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    continue;
                }
                else if(frames6[3][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    continue;
                }
                else if(frames6[4][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    continue;
                }
                else if(frames6[5][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    continue;
                }
                if(i != (ref.length-1)){
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames6[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames6[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames6[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames6[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames6[4][0] == ref[j])
                            break;
                        counter[4][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames6[5][0] == ref[j])
                            break;
                        counter[5][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0]) && (counter[0][0] > counter[5][0])){
                        frames6[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0]) && (counter[1][0] > counter[5][0])){
                        frames6[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0]) && (counter[2][0] > counter[5][0])){
                        frames6[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0]) && (counter[3][0] > counter[5][0])){
                        frames6[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0]) && (counter[4][0] > counter[5][0])){
                        frames6[4][0] = ref[i];
                        counter2[4][0] = 0;
                        faults++;
                    }
                    else if((counter[5][0] > counter[0][0]) && (counter[5][0] > counter[1][0]) && (counter[5][0] > counter[2][0]) && (counter[5][0] > counter[3][0]) && (counter[5][0] > counter[4][0])){
                        frames6[5][0] = ref[i];
                        counter2[5][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0]) && (counter2[0][0] > counter2[4][0]) && (counter2[0][0] > counter2[5][0])){
                            frames6[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0]) && (counter2[1][0] > counter2[4][0]) && (counter2[1][0] > counter2[5][0])){
                            frames6[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0]) && (counter2[2][0] > counter2[4][0]) && (counter2[2][0] > counter[5][0])){
                            frames6[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0]) && (counter2[3][0] > counter2[4][0]) && (counter2[3][0] > counter2[5][0])){
                            frames6[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                        else if((counter2[4][0] > counter2[0][0]) && (counter2[4][0] > counter2[1][0]) && (counter2[4][0] > counter2[2][0]) && (counter2[4][0] > counter2[3][0]) && (counter2[4][0] > counter2[5][0])){
                            frames6[4][0] = ref[i];
                            counter2[4][0] = 0;
                            faults++;
                        }
                        else if((counter2[5][0] > counter2[0][0]) && (counter2[5][0] > counter2[1][0]) && (counter2[5][0] > counter2[2][0]) && (counter2[5][0] > counter2[3][0]) && (counter2[5][0] > counter2[4][0])){
                            frames6[5][0] = ref[i];
                            counter2[5][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter[4][0] = 0;
                    counter[5][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                }
                else if(i == (ref.length - 1)){
                    for(int j = i; j < ref.length; j++){
                        if(frames6[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames6[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames6[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames6[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames6[4][0] == ref[j])
                            break;
                        counter[4][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames6[5][0] == ref[j])
                            break;
                        counter[5][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0]) && (counter[0][0] > counter[5][0])){
                        frames6[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0]) && (counter[1][0] > counter[5][0])){
                        frames6[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0]) && (counter[2][0] > counter[5][0])){
                        frames6[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0]) && (counter[3][0] > counter[5][0])){
                        frames6[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0]) && (counter[4][0] > counter[5][0])){
                        frames6[4][0] = ref[i];
                        counter2[4][0] = 0;
                        faults++;
                    }
                    else if((counter[5][0] > counter[0][0]) && (counter[5][0] > counter[1][0]) && (counter[5][0] > counter[2][0]) && (counter[5][0] > counter[3][0]) && (counter[5][0] > counter[4][0])){
                        frames6[5][0] = ref[i];
                        counter2[5][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0]) && (counter2[0][0] > counter2[4][0]) && (counter2[0][0] > counter2[5][0])){
                            frames6[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0]) && (counter2[1][0] > counter2[4][0]) && (counter2[1][0] > counter2[5][0])){
                            frames6[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0]) && (counter2[2][0] > counter2[4][0]) && (counter2[2][0] > counter[5][0])){
                            frames6[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0]) && (counter2[3][0] > counter2[4][0]) && (counter2[3][0] > counter2[5][0])){
                            frames6[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                        else if((counter2[4][0] > counter2[0][0]) && (counter2[4][0] > counter2[1][0]) && (counter2[4][0] > counter2[2][0]) && (counter2[4][0] > counter2[3][0]) && (counter2[4][0] > counter2[5][0])){
                            frames6[4][0] = ref[i];
                            counter2[4][0] = 0;
                            faults++;
                        }
                        else if((counter2[5][0] > counter2[0][0]) && (counter2[5][0] > counter2[1][0]) && (counter2[5][0] > counter2[2][0]) && (counter2[5][0] > counter2[3][0]) && (counter2[5][0] > counter2[4][0])){
                            frames6[5][0] = ref[i];
                            counter2[5][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter[4][0] = 0;
                    counter[5][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                }
            }
        }
        System.out.println("OPR page faults for 6 frames: " + faults);
        faults = 0;
        
        //7 Frames
        for(int i = 0; i < ref.length; i++){
            if(i < frames7.length){
                if(i > 0){
                    if(frames7[0][0] == ref[i]){
                        counter2[0][0]++;
                        continue;
                    }
                    else if(frames7[1][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        continue;
                    }
                    else if(frames7[2][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        continue;
                    }
                    else if(frames7[3][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        counter2[3][0]++;
                        continue;
                    }
                    else if(frames7[4][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        counter2[3][0]++;
                        counter2[4][0]++;
                        continue;
                    }
                    else if(frames7[5][0] == ref[i]){
                        counter2[0][0]++;
                        counter2[1][0]++;
                        counter2[2][0]++;
                        counter2[3][0]++;
                        counter2[4][0]++;
                        counter2[5][0]++;
                        continue;
                    }
                }
                frames7[i][0] = ref[i];
                if(i == 0)
                    counter2[0][0]++;
                if(i == 1){
                    counter2[0][0]++;
                    counter2[1][0]++;
                }
                if(i == 2){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                }
                if(i == 3){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                }
                if(i == 4){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                }
                if(i == 5){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                }
                if(i == 6){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                }
                faults++;
            }
            else{
                if(frames7[0][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                else if(frames7[1][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                else if(frames7[2][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                else if(frames7[3][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                else if(frames7[4][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                else if(frames7[5][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                else if(frames7[6][0] == ref[i]){
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                    continue;
                }
                if(i != (ref.length-1)){
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[4][0] == ref[j])
                            break;
                        counter[4][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[5][0] == ref[j])
                            break;
                        counter[5][0]++;
                    }
                    for(int j = (i+1); j < ref.length; j++){
                        if(frames7[6][0] == ref[j])
                            break;
                        counter[6][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0]) && (counter[0][0] > counter[5][0]) && (counter[0][0] > counter[6][0])){
                        frames7[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0]) && (counter[1][0] > counter[5][0]) && (counter[1][0] > counter[6][0])){
                        frames7[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0]) && (counter[2][0] > counter[5][0]) && (counter[2][0] > counter[6][0])){
                        frames7[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0]) && (counter[3][0] > counter[5][0]) && (counter[3][0] > counter[6][0])){
                        frames7[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0]) && (counter[4][0] > counter[5][0]) && (counter[4][0] > counter[6][0])){
                        frames7[4][0] = ref[i];
                        counter2[4][0] = 0;
                        faults++;
                    }
                    else if((counter[5][0] > counter[0][0]) && (counter[5][0] > counter[1][0]) && (counter[5][0] > counter[2][0]) && (counter[5][0] > counter[3][0]) && (counter[5][0] > counter[4][0]) && (counter[5][0] > counter[6][0])){
                        frames6[5][0] = ref[i];
                        counter2[5][0] = 0;
                        faults++;
                    }
                    else if((counter[6][0] > counter[0][0]) && (counter[6][0] > counter[1][0]) && (counter[6][0] > counter[2][0]) && (counter[6][0] > counter[3][0]) && (counter[6][0] > counter[4][0]) && (counter[6][0] > counter[5][0])){
                        frames6[6][0] = ref[i];
                        counter2[6][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0]) && (counter2[0][0] > counter2[4][0]) && (counter2[0][0] > counter2[5][0]) && (counter2[0][0] > counter2[6][0])){
                            frames7[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0]) && (counter2[1][0] > counter2[4][0]) && (counter2[1][0] > counter2[5][0]) && (counter2[1][0] > counter2[6][0])){
                            frames7[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0]) && (counter2[2][0] > counter2[4][0]) && (counter2[2][0] > counter[5][0]) && (counter2[2][0] > counter2[6][0])){
                            frames7[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0]) && (counter2[3][0] > counter2[4][0]) && (counter2[3][0] > counter2[5][0]) && (counter2[3][0] > counter2[6][0])){
                            frames7[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                        else if((counter2[4][0] > counter2[0][0]) && (counter2[4][0] > counter2[1][0]) && (counter2[4][0] > counter2[2][0]) && (counter2[4][0] > counter2[3][0]) && (counter2[4][0] > counter2[5][0]) && (counter2[4][0] > counter2[6][0])){
                            frames7[4][0] = ref[i];
                            counter2[4][0] = 0;
                            faults++;
                        }
                        else if((counter2[5][0] > counter2[0][0]) && (counter2[5][0] > counter2[1][0]) && (counter2[5][0] > counter2[2][0]) && (counter2[5][0] > counter2[3][0]) && (counter2[5][0] > counter2[4][0]) && (counter2[5][0] > counter2[6][0])){
                            frames7[5][0] = ref[i];
                            counter2[5][0] = 0;
                            faults++;
                        }
                        else if((counter2[6][0] > counter2[0][0]) && (counter2[6][0] > counter2[1][0]) && (counter2[6][0] > counter2[2][0]) && (counter2[6][0] > counter2[3][0]) && (counter2[6][0] > counter2[4][0]) && (counter2[6][0] > counter2[5][0])){
                            frames7[6][0] = ref[i];
                            counter2[6][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter[4][0] = 0;
                    counter[5][0] = 0;
                    counter[6][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                }
                else if(i == (ref.length - 1)){
                    for(int j = i; j < ref.length; j++){
                        if(frames7[0][0] == ref[j])
                            break;
                        counter[0][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames7[1][0] == ref[j])
                            break;
                        counter[1][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames7[2][0] == ref[j])
                            break;
                        counter[2][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames7[3][0] == ref[j])
                            break;
                        counter[3][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames7[4][0] == ref[j])
                            break;
                        counter[4][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames7[5][0] == ref[j])
                            break;
                        counter[5][0]++;
                    }
                    for(int j = i; j < ref.length; j++){
                        if(frames7[6][0] == ref[j])
                            break;
                        counter[6][0]++;
                    }
                    if((counter[0][0] > counter[1][0]) && (counter[0][0] > counter[2][0]) && (counter[0][0] > counter[3][0]) && (counter[0][0] > counter[4][0]) && (counter[0][0] > counter[5][0]) && (counter[0][0] > counter[6][0])){
                        frames7[0][0] = ref[i];
                        counter2[0][0] = 0;
                        faults++;
                    }
                    else if((counter[1][0] > counter[0][0]) && (counter[1][0] > counter[2][0]) && (counter[1][0] > counter[3][0]) && (counter[1][0] > counter[4][0]) && (counter[1][0] > counter[5][0]) && (counter[1][0] > counter[6][0])){
                        frames7[1][0] = ref[i];
                        counter2[1][0] = 0;
                        faults++;
                    }
                    else if((counter[2][0] > counter[0][0]) && (counter[2][0] > counter[1][0]) && (counter[2][0] > counter[3][0]) && (counter[2][0] > counter[4][0]) && (counter[2][0] > counter[5][0]) && (counter[2][0] > counter[6][0])){
                        frames7[2][0] = ref[i];
                        counter2[2][0] = 0;
                        faults++;
                    }
                    else if((counter[3][0] > counter[0][0]) && (counter[3][0] > counter[1][0]) && (counter[3][0] > counter[2][0]) && (counter[3][0] > counter[4][0]) && (counter[3][0] > counter[5][0]) && (counter[3][0] > counter[6][0])){
                        frames7[3][0] = ref[i];
                        counter2[3][0] = 0;
                        faults++;
                    }
                    else if((counter[4][0] > counter[0][0]) && (counter[4][0] > counter[1][0]) && (counter[4][0] > counter[2][0]) && (counter[4][0] > counter[3][0]) && (counter[4][0] > counter[5][0]) && (counter[4][0] > counter[6][0])){
                        frames7[4][0] = ref[i];
                        counter2[4][0] = 0;
                        faults++;
                    }
                    else if((counter[5][0] > counter[0][0]) && (counter[5][0] > counter[1][0]) && (counter[5][0] > counter[2][0]) && (counter[5][0] > counter[3][0]) && (counter[5][0] > counter[4][0]) && (counter[5][0] > counter[6][0])){
                        frames6[5][0] = ref[i];
                        counter2[5][0] = 0;
                        faults++;
                    }
                    else if((counter[6][0] > counter[0][0]) && (counter[6][0] > counter[1][0]) && (counter[6][0] > counter[2][0]) && (counter[6][0] > counter[3][0]) && (counter[6][0] > counter[4][0]) && (counter[6][0] > counter[5][0])){
                        frames6[6][0] = ref[i];
                        counter2[6][0] = 0;
                        faults++;
                    }
                    else{
                        if((counter2[0][0] > counter2[1][0]) && (counter2[0][0] > counter2[2][0]) && (counter2[0][0] > counter2[3][0]) && (counter2[0][0] > counter2[4][0]) && (counter2[0][0] > counter2[5][0]) && (counter2[0][0] > counter2[6][0])){
                            frames7[0][0] = ref[i];
                            counter2[0][0] = 0;
                            faults++;
                        }
                        else if((counter2[1][0] > counter2[0][0]) && (counter2[1][0] > counter2[2][0]) && (counter2[1][0] > counter2[3][0]) && (counter2[1][0] > counter2[4][0]) && (counter2[1][0] > counter2[5][0]) && (counter2[1][0] > counter2[6][0])){
                            frames7[1][0] = ref[i];
                            counter2[1][0] = 0;
                            faults++;
                        }
                        else if((counter2[2][0] > counter2[0][0]) && (counter2[2][0] > counter2[1][0]) && (counter2[2][0] > counter2[3][0]) && (counter2[2][0] > counter2[4][0]) && (counter2[2][0] > counter[5][0]) && (counter2[2][0] > counter2[6][0])){
                            frames7[2][0] = ref[i];
                            counter2[2][0] = 0;
                            faults++;
                        }
                        else if((counter2[3][0] > counter2[0][0]) && (counter2[3][0] > counter2[1][0]) && (counter2[3][0] > counter2[2][0]) && (counter2[3][0] > counter2[4][0]) && (counter2[3][0] > counter2[5][0]) && (counter2[3][0] > counter2[6][0])){
                            frames7[3][0] = ref[i];
                            counter2[3][0] = 0;
                            faults++;
                        }
                        else if((counter2[4][0] > counter2[0][0]) && (counter2[4][0] > counter2[1][0]) && (counter2[4][0] > counter2[2][0]) && (counter2[4][0] > counter2[3][0]) && (counter2[4][0] > counter2[5][0]) && (counter2[4][0] > counter2[6][0])){
                            frames7[4][0] = ref[i];
                            counter2[4][0] = 0;
                            faults++;
                        }
                        else if((counter2[5][0] > counter2[0][0]) && (counter2[5][0] > counter2[1][0]) && (counter2[5][0] > counter2[2][0]) && (counter2[5][0] > counter2[3][0]) && (counter2[5][0] > counter2[4][0]) && (counter2[5][0] > counter2[6][0])){
                            frames7[5][0] = ref[i];
                            counter2[5][0] = 0;
                            faults++;
                        }
                        else if((counter2[6][0] > counter2[0][0]) && (counter2[6][0] > counter2[1][0]) && (counter2[6][0] > counter2[2][0]) && (counter2[6][0] > counter2[3][0]) && (counter2[6][0] > counter2[4][0]) && (counter2[6][0] > counter2[5][0])){
                            frames7[6][0] = ref[i];
                            counter2[6][0] = 0;
                            faults++;
                        }
                    }
                    counter[0][0] = 0;
                    counter[1][0] = 0;
                    counter[2][0] = 0;
                    counter[3][0] = 0;
                    counter[4][0] = 0;
                    counter[5][0] = 0;
                    counter[6][0] = 0;
                    counter2[0][0]++;
                    counter2[1][0]++;
                    counter2[2][0]++;
                    counter2[3][0]++;
                    counter2[4][0]++;
                    counter2[5][0]++;
                    counter2[6][0]++;
                }
            }
        }
        System.out.println("OPR page faults for 7 frames: " + faults);
        faults = 0;
    }
    
    public static int[] populateString(int[] ref){
        for(int i = 0; i < 10; i++){
            ref[i] = (int)(Math.random()*9);
            System.out.print(ref[i] + " ");
        }
        System.out.println("\n");
        return ref;
    }
}